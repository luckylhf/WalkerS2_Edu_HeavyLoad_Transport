"""UBT Robot API Python Bindings

This package provides Python bindings for the UBT Robot Control Center API.
"""

from ._core import (
    Api,
    Config,
    Response,
    Work,
    WorkState,
    WorkResult,
    WorkResultType,
    Skill,
)

__version__ = "1.0.0"
__author__ = "UBT Robotics"

__all__ = [
    "Api",
    "Config",
    "Response",
    "Work",
    "WorkState",
    "WorkResult",
    "WorkResultType",
    "Skill",
]
